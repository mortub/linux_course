Author: Mor Tubul
Id: 311420418

notes:
1. I added to the p2p.h
2. the printings aren't exactly the same, but understandable
3. I started from #define P_SRV_PORT 12347 because the computer didn't let me use the #define P_SRV_PORT 12345...
I probably didn't close something during development