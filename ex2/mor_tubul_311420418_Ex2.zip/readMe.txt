mor tubul 
מור טובול
id: 311420418

note:
the compilation worked for me with :
gcc -no-pie -o scantree main.o scantree.c